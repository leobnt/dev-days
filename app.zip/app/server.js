const express = require('express');
const request = require('request');
const path = require('path');
const bagsData = require('./bags.json')
const app = express();

var CLIENT = '';
var SECRET = '';
var PAYPAL_API = 'https://api-m.sandbox.paypal.com';

app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));
app.use(express.static(__dirname + '/public'));

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, './public/app.html'));
});

app.post('/create-order/', (req, res) => {
    const itemId = req.body.itemId;
    const item = bagsData.find((item) => item.itemId == itemId);

    var options = {
        'method': 'POST',
        'url': `${PAYPAL_API}/v2/checkout/orders`,
        'headers': {
            'Content-Type': 'application/json',
        },
        auth: {
            user: CLIENT,
            pass: SECRET
        },
        body: JSON.stringify({
            "intent": "CAPTURE",
            "purchase_units": [{
                "amount": {
                    "currency_code": "EUR",
                    "value": item.itemPrice
                },
                "shipping": {
                    "address": {
                        "address_line_1": "21 Rue de la Banque",
                        "admin_area_2": "Paris",
                        "admin_area_1": "CA",
                        "postal_code": "75002",
                        "country_code": "FR"
                    }
                }
            }]
        })

    };
    request(options, function (err, response) {
        if (err) throw new Error(err);
        return res.send(response.body);
    });
});

app.post('/create-order-ecs/', (req, res) => {
    const itemId = req.body.itemId;
    const item = bagsData.find((item) => item.itemId == itemId);

    var options = {
        'method': 'POST',
        'url': `${PAYPAL_API}/v2/checkout/orders`,
        'headers': {
            'Content-Type': 'application/json',
        },
        auth: {
            user: CLIENT,
            pass: SECRET
        },
        body: JSON.stringify({
            "intent": "AUTHORIZE",
            "application_context": {
                "shipping_preference": "GET_FROM_FILE",
                "user_action": "PAY_NOW",
            },
            "purchase_units": [{
                "amount": {
                    "currency_code": "EUR",
                    "value": item.itemPrice
                },
                "shipping": {
                    "address": {
                        "address_line_1": "21 Rue de la Banque",
                        "admin_area_2": "Paris",
                        "admin_area_1": "CA",
                        "postal_code": "75002",
                        "country_code": "FR"
                    }
                }
            }]
        })

    };
    request(options, function (error, response) {
        if (error) throw new Error(error);
        return res.send(response.body);
    });
});

app.post('/capture-order/:orderId', (req, res) => {
    var orderID = req.params.orderId;

    var options = {
        'method': 'POST',
        'url': `${PAYPAL_API}/v2/checkout/orders/${orderID}/capture`,
        'headers': {
            'Content-Type': 'application/json',
        },
        auth: {
            user: CLIENT,
            pass: SECRET
        }
    };
    request(options, function (error, response) {
        if (error) throw new Error(error);
        return res.send(response.body);
    });
})

app.post('/authorize-order/:orderId', (req, res) => {
    var orderID = req.params.orderId;
    var options = {
        'method': 'POST',
        'url': `${PAYPAL_API}/v2/checkout/orders/${orderID}/authorize`,
        'headers': {
            'Content-Type': 'application/json',
        },
        auth: {
            user: CLIENT,
            pass: SECRET
        }
    };
    request(options, function (error, response) {
        if (error) throw new Error(error);
        return res.send(response.body);
    });
})

app.post('/get-order-details/:orderId', (req, res) => {
    const orderID = req.params.orderId;

    var options = {
        'method': 'GET',
        'url': `${PAYPAL_API}/v2/checkout/orders/${orderID}`,
        'headers': {
            'Content-Type': 'application/json',
        },
        auth: {
            user: CLIENT,
            pass: SECRET
        }
    };
    request(options, function (error, response) {
        if (error) throw new Error(error);
        console.log(response.body);
        return res.send(response.body);
    });
});

app.get('/bags', (req, res) => {
    res.send(bagsData);
});

app.listen(8000, () => {
    console.log("ShopApp started on port 8000")
})