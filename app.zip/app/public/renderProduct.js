// JavaScript code to open and close the modal and switch between pages
var modal;
var overlay;
var closeButton;
var shopping;
var shipping;
var checkout;
var completed;

var productItems;
var selectedProduct;

function setVariables() {
  modal = document.getElementById("modalCheckout");
  overlay = document.getElementById("overlay");
  closeButton = document.getElementById("closeModal");
  shopping = document.getElementById("shopping");
  shipping = document.getElementById("shipping");
  checkout = document.getElementById("checkout");
  completed = document.getElementById("completed");
}

function loadProduct() {
  fetch('http://localhost:8000/bags/', {
    method: 'GET'
  }).then(function (res) {
    return res.json();
  }).then(function (data) {
    productItems = data;
    renderProducts();
  });
}

function closeBasketModal() {
  modal.style.display = "none";
  overlay.style.display = "none";
}

function showPage(pageId) {
  shopping.style.display = "none";
  shipping.style.display = "none";
  checkout.style.display = "none";
  completed.style.display = "none";
  document.getElementById(pageId).style.display = "block";
  modal.style.display = "block";
  overlay.style.display = "block";
}

function renderProducts() {
  const element = document.getElementById("productItems");
  const productList = productItems.map(product => `
      <div class="item">
        <div class="item-img-grid">
          <img class="item-img" alt="pic" src="${product.itemImg}">
        </div>
        <div class="item-name-grid">
          <h3 class="item-name">${product.itemName}</h3>
          <div>
            <p class="item-price">${product.itemPrice}</p>
            <p class="item-currency">€</p>
            <button class="btn-add-to-cart" onClick="renderProductToBuy(${product.itemId})">Buy</button>
          </div>
        </div>
      </div>
      `).reduce((acc, cur) => acc.concat(cur));
  element.innerHTML = `
        <div class="item-grid">
          ${productList}
        </div>
      `;
}

function renderProductToBuy(productId) {
  const element = document.getElementById("productToBuy");
  selectedProduct = productItems.find(product => product.itemId === productId);
  element.innerHTML = `
      <div class="item-minimal">
        <img class="item-img minimal" alt="pic" src="${selectedProduct.itemImg}">
        <h3 class="item-name minimal">${selectedProduct.itemName}</h3>
      </div>
      <div class="total-price">
        <h4>Total</h4>
        <h4 class="price">${selectedProduct.itemPrice} €</h4>
      </div>
      `;
  showPage('shopping');
}